<?php $__env->startSection('title','Add New Post'); ?> 
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          
          <ol class="breadcrumb">
            <li>
            <a href="<?php echo e(route('home')); ?>">
            <i class="fa fa-dashboard"></i> Dashboard
            </a>
            </li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
              <div class="col-xs-12">
                <div class="box">
                  <!-- /.box-header -->
                           
                  
                  <div class="box-body ">

                  <?php echo Form::model($event, [

                   'method'=>'Post',

                   'route' => ['info.store',$event->id],

                   'files'=>TRUE,

                   ]); ?>


                    
                    

                    <div class="form-group <?php echo e($errors->has('body') ? 'has-error' :''); ?>">
                      
                      <?php echo Form::label('body'); ?>


                     <?php echo Form::textarea('body', null,['class'=>'form-control','id'=>'MyID']); ?>


                     <?php if($errors->has('body')): ?>

                      <span class="help-block"><?php echo e($errors->first('body')); ?></span>

                      <?php endif; ?>
                    </div>

                    <div class="form-group <?php echo e($errors->has('date') ? 'has-error' :''); ?>">
                      
                      <?php echo Form::label('date','date'); ?>


                

                         <div class='input-group date' id='published_at'>
                   <?php echo Form::text('date', null,['class'=>'form-control','placeholder'=>'Y-m-d H:i:m']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>

                
                 <?php if($errors->has('date')): ?>

                      <span class="help-block"><?php echo e($errors->first('date')); ?></span>

                      <?php endif; ?>

                    </div>
                    

                    
                    

                    <hr>

                    <?php echo Form::submit('Create New Post',['class'=>'btn btn-primary']);; ?>



                    <?php echo Form::close(); ?>

                        
                  </div>
                  
                 
                </div>
                <!-- /.box -->
              </div>
            </div>
          <!-- ./row -->
        </section>
        <!-- /.content -->
      </div>


     
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>