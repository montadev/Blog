<div>
   Merci d'etre un membre dans notre Association: <?php echo e($name); ?>

</div>