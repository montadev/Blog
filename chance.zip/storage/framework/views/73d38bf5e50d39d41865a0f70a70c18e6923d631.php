<?php $__env->startSection('title','Add New Post'); ?> 
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <?php if($post->exists): ?>
             
             update post
            <?php else: ?>

            Add New Post

            <?php endif; ?>
            
          </h1>
          <ol class="breadcrumb">
            <li>
            <a href="<?php echo e(route('home')); ?>">
            <i class="fa fa-dashboard"></i> Dashboard
            </a>
            </li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
              <div class="col-xs-12">
                <div class="box">
                  <!-- /.box-header -->
                           
                  
                  <div class="box-body ">

                  <?php echo Form::model($post, [

                   'method'=>'Put',

                  'route' => ['blog.update',$post->id],

                   'files'=>TRUE,

                   ]); ?>


                    <div class="form-group <?php echo e($errors->has('title') ? 'has-error' :''); ?>">
                      
                      <?php echo Form::label('title'); ?>


                     <?php echo Form::text('title', null,['class'=>'form-control']); ?>


                      <?php if($errors->has('title')): ?>

                      <span class="help-block"><?php echo e($errors->first('title')); ?></span>

                      <?php endif; ?>
                    </div>

                    

                    <div class="form-group <?php echo e($errors->has('body') ? 'has-error' :''); ?>">
                      
                      <?php echo Form::label('body'); ?>


                     <?php echo Form::textarea('body', null,['class'=>'form-control','id'=>'MyID']); ?>


                     <?php if($errors->has('body')): ?>

                      <span class="help-block"><?php echo e($errors->first('body')); ?></span>

                      <?php endif; ?>
                    </div>

                    <div class="form-group <?php echo e($errors->has('published_at') ? 'has-error' :''); ?>">
                      
                      <?php echo Form::label('published_at','published date'); ?>


                

                         <div class='input-group date' id='published_at'>
                   <?php echo Form::text('published_at', null,['class'=>'form-control','placeholder'=>'Y-m-d H:i:m','id'=>'published_at']); ?>

                    <span class="input-group-addon">
                        <span class="glyphicon glyphicon-calendar"></span>
                    </span>
                </div>
                 <?php if($errors->has('published_at')): ?>

                      <span class="help-block"><?php echo e($errors->first('published_at')); ?></span>

                      <?php endif; ?>

                    </div>
                    

                    <div class="form-group">
                      
                      <?php echo Form::label('category_id','Category'); ?>


              <?php echo Form::select('category_id',App\Category::pluck('title','id'), null,['class'=>'form-control']); ?>

                    </div>


                    <div class="form-group">
                      
                      <?php echo Form::label('type_id','Type'); ?>


              <?php echo Form::select('type_id',App\PostType::pluck('type','id'), null,['class'=>'form-control']); ?>

                    </div>

                    <div class="form-group <?php echo e($errors->has('image') ? 'has-error' :''); ?>">
                      
                    

                      <div class="fileinput fileinput-new" data-provides="fileinput">
                          <div class="fileinput-new img-thumbnail" style="width: 200px; height: 150px;">
                            <img src="<?php echo e(($post->image) ? $post->image : 'https://placehold.it/200x150&text=No+Image'); ?>"  alt="..." style="width: 200px; height: 150px;">
                          </div>

                          <div class="fileinput-preview fileinput-exists img-thumbnail" style="max-width: 200px; max-height: 150px;">
                            
                          </div>

                          <div>
                            <span class="btn btn-outline-secondary btn-file" style="border:1px solid grey;margin-top:10px"><span class="fileinput-new">Select image</span><span class="fileinput-exists">Change</span><input type="file" name="image"></span>
                            <a href="#" class="btn btn-outline-secondary fileinput-exists" data-dismiss="fileinput">Remove</a>
                          </div>

                        </div>

                      

                       <?php if($errors->has('image')): ?>

                      <span class="help-block"><?php echo e($errors->first('image')); ?></span>

                      <?php endif; ?>

                    </div>

                    <hr>

                    <?php echo Form::submit('Update Post',['class'=>'btn btn-primary']);; ?>



                    <?php echo Form::close(); ?>

                        
                  </div>
                  
                 
                </div>
                <!-- /.box -->
              </div>
            </div>
          <!-- ./row -->
        </section>
        <!-- /.content -->
      </div>


     
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>