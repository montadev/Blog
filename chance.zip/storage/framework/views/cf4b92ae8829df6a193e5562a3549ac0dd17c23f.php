<?php $__env->startSection('title','My Blog'); ?> 
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Display All Posts
          </h1>
          <ol class="breadcrumb">
            <li>
            <a href="<?php echo e(route('home')); ?>">
            <i class="fa fa-dashboard"></i> Dashboard
            </a>
            </li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
              <div class="col-xs-12">
                <div class="box">
                  <!-- /.box-header -->

                  <div class="box-header">
                    
                    <div class="pull-left">
                      <a href="<?php echo e(route('blog.create')); ?>" class="btn btn-success">
                        Add New Post
                      </a>
                    </div>
                  </div>
                  <div class="box-body ">

                       <?php if(!$posts->count()): ?>
                    <div class="alert alert-danger">
                      <srong>No record found</srong>
                    </div>
                      <?php else: ?>
                       
                      <table class="table table-bordered">
                          <thead>
                            <tr>
                              <th>Action</th>
                              <th>Title</th>
                              <th>Author</th>
                              <th>type</th>
                              <th>Category</th>
                              <th>Date</th>
                              <th>status</th>

                               <?php if(Auth::user()->role->title=='admin'): ?>
                              <th>action</th>
                               <?php endif; ?>
                            </tr>
                          </thead>
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tbody>

                            <?php if(Auth::user()->role->title=='admin'|| Auth::user()->role->title=='editor'): ?>
                          <tr>
                            <td>

                            <a href="<?php echo e(route('blog.edit',$post->id)); ?>" class="btn btn-xs btn-default"><i class="fa fa-edit"></i></a>
                       <?php echo Form::open(['method' => 'DELETE','route' =>['blog.destroy',$post->id] ]); ?>


                            <button type="submit" class="btn btn-xs btn-danger">
                            <i class="fa fa-times"></i>
                            </button>
                            <?php echo Form::close(); ?>

                            </td>
                            <td><?php echo e($post->title); ?></td>
                            <td><?php echo e($post->user->name); ?></td>
                            <td><?php echo e($post->type->type); ?></td>
                            <td><?php echo e($post->category->title); ?></td>
                            <td><abbr title="<?php echo e($post->dateFormatted(true)); ?>"><?php echo e($post->dateFormatted()); ?></abbr>

                            <?php echo $post->publicationLabel(); ?>


                            </td>
                            <td>
                              
                              <?php if($post->validate): ?>

                                 <span class="label label-success">Validé</span>
                                
                                  
                              <?php else: ?>
                               <span class="label label-danger">Encours de validation</span>

                              <?php endif; ?>


                            </td>
                                
                                 <?php if(Auth::user()->role->title=='admin'): ?>
                                  <td>
                                  <a href="<?php echo e(route('valide',$post->id)); ?>"><span class="label label-success">Validé</span></a>
                                  <a href="<?php echo e(route('rejete',$post->id)); ?>"><span class="label label-danger">Rejeté</span></a>
                                  </td>
                                 <?php endif; ?>
                            
                          </tr>
                             <?php else: ?>

                                     <?php if($post->user->email==Auth::user()->email): ?>
                                          
                                           <tr>
                                                  <td>

                                                  <a href="<?php echo e(route('blog.edit',$post->id)); ?>" class="btn btn-xs btn-default"><i class="fa fa-edit"></i></a>
                                             <?php echo Form::open(['method' => 'DELETE','route' =>['blog.destroy',$post->id] ]); ?>


                                                  <button type="submit" class="btn btn-xs btn-danger">
                                                  <i class="fa fa-times"></i>
                                                  </button>
                                                  <?php echo Form::close(); ?>

                                                  </td>
                                                  <td><?php echo e($post->title); ?></td>
                                                  <td><?php echo e($post->user->name); ?></td>
                                                  <td><?php echo e($post->type->type); ?></td>
                                                  <td><?php echo e($post->category->title); ?></td>
                                                  <td><abbr title="<?php echo e($post->dateFormatted(true)); ?>"><?php echo e($post->dateFormatted()); ?></abbr>

                                                  <?php echo $post->publicationLabel(); ?>


                                                  </td>

                                                  <td>
                              
                                                <?php if($post->validate): ?>

                                                   <span class="label label-success">Validé</span>
                                                  
                                                    
                                                <?php else: ?>
                                                 <span class="label label-danger">Encours de validation</span>

                                                <?php endif; ?>


                                                    </td>

                                                     <?php if(Auth::user()->role->title=='admin'): ?>
                                                     <td>
                                                     <a href="<?php echo e(route('valide',$post->id)); ?>"><span class="label label-success">Validé</span></a>
                                                     <a href="<?php echo e(route('rejete',$post->id)); ?>"><span class="label label-success">Rejeté</span></a>
                                                     </td>
                                                     <?php endif; ?>


                                                  </tr>

                                     <?php endif; ?>  
                              

                             <?php endif; ?>
                          </tbody>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
                    </table>
                    <?php endif; ?>  
                        
                  </div>
                  
                  <div class="box-footer clearfix">
                    <div class="pull-left">
                    <ul class="pagination no-margin">
                      <?php echo e($posts->links()); ?>

                   </ul>
                   </div>
                   <div class="pull-right">
                      <small><?php echo e($postcount); ?> items</small>
                   </div>
                  </div>
                </div>
                <!-- /.box -->
              </div>
            </div>
          <!-- ./row -->
        </section>
        <!-- /.content -->
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>