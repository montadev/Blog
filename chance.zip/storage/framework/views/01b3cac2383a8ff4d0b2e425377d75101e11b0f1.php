<?php $__env->startSection('title','Add New Post'); ?> 
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <?php if($category->exists): ?>
             
             update Category
            <?php else: ?>

            Add New Category

            <?php endif; ?>
            
          </h1>
          <ol class="breadcrumb">
            <li>
            <a href="<?php echo e(route('home')); ?>">
            <i class="fa fa-dashboard"></i> Dashboard
            </a>
            </li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
              <div class="col-xs-12">
                <div class="box">
                  <!-- /.box-header -->
                           
                  
                  <div class="box-body ">

                  <?php echo Form::model($category, [

                   'method'=>'PUT',

                   'route' => ['categories.update',$category->id],

                   'files'=>TRUE,

                   ]); ?>


                    <div class="form-group <?php echo e($errors->has('title') ? 'has-error' :''); ?>">
                      
                      <?php echo Form::label('title'); ?>


                     <?php echo Form::text('title', null,['class'=>'form-control']); ?>


                      <?php if($errors->has('title')): ?>

                      <span class="help-block"><?php echo e($errors->first('title')); ?></span>

                      <?php endif; ?>
                    </div>

                    

                    

                    
                    

                    

                    

                    <hr>

                    <?php echo Form::submit('Create New Category',['class'=>'btn btn-primary']);; ?>



                    <?php echo Form::close(); ?>

                        
                  </div>
                  
                 
                </div>
                <!-- /.box -->
              </div>
            </div>
          <!-- ./row -->
        </section>
        <!-- /.content -->
      </div>


     
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>