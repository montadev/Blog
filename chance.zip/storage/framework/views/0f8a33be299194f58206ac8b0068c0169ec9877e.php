<?php $__env->startSection('content'); ?>
<div class="login-box">
  <div class="login-logo">
    <a href="../../index2.html"><b>Blog</b> 3w Academy</a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Sign in to start your session</p>

      <?php if(Session::get('status')): ?>

                 <span style="color:red;"><?php echo e(Session::get('status')); ?></span>
      <?php endif; ?>
    <form method="POST" action="<?php echo e(route('login')); ?>">
             <?php echo csrf_field(); ?>

              <?php if($errors->has('email')): ?>

                <span class="invalid-feedback " role="alert">
                    <strong style="color:red;"><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>


      <div class="form-group has-feedback">
        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
        <span class="fa fa-envelope form-control-feedback"></span>
                      
      </div>


      <div class="form-group has-feedback">
        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>
        <span class="fa fa-lock form-control-feedback"></span>
        <?php if($errors->has('password')): ?>
                 <span class="invalid-feedback" role="alert">
                     <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
                     <?php endif; ?>
      </div>


      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
              <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat"><?php echo e(__('Login')); ?></button>
        </div>
        <!-- /.col -->
      </div>
    </form>

    <br>
    <a href="<?php echo e(route('password.request')); ?>">I forgot my password</a><br>

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>