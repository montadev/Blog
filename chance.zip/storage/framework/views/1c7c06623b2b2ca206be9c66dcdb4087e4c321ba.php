<?php $__env->startSection('title','My Info'); ?> 
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Display All Pub
          </h1>
          <ol class="breadcrumb">
            <li>
            <a href="<?php echo e(route('home')); ?>">
            <i class="fa fa-dashboard"></i> Dashboard
            </a>
            </li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
              <div class="col-xs-12">
                <div class="box">
                  <!-- /.box-header -->

                  <div class="box-header">
                    
                    <div class="pull-left">
                      <a href="<?php echo e(route('blog.pub')); ?>" class="btn btn-success">
                        Add New Pub
                      </a>
                    </div>
                  </div>
                  <div class="box-body ">

                       <?php if(!$pubs->count()): ?>
                    <div class="alert alert-danger">
                      <srong>No record found</srong>
                    </div>
                      <?php else: ?>
                       
                      <table class="table table-bordered">
                          <thead>
                            <tr>
                              
                              <th>Title</th>
                               <th>Date debut</th>
                                <th>Date de fin</th>
                                <th>Action</th>
                            </tr>
                          </thead>
                            <?php $__currentLoopData = $pubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tbody>
                          <tr>
                           

                            <td><?php echo e($pub->title); ?></td>
                            <td>
                            <?php echo e($pub->date_debut); ?>

                            

                            </td>
                            <td><?php echo e($pub->date_fin); ?></td>
                            <td>
                              <a href="<?php echo e(route('blog.pub.delete',$pub->id)); ?>"><button onclick="return confirm('Are you sure to delete');" type="submit" class="btn btn-xs btn-danger">
                            <i class="fa fa-times"></i>
                            </button>
                            </a>

                            <a href="<?php echo e(route('blog.pub.update',$pub->id)); ?>"><button onclick="return confirm('Are you sure to update');" type="submit" class="btn btn-xs btn-success">
                            <i class="fa fa-times"></i>
                            </button>
                            </a>
                            </td>
                          </tr>
                          </tbody>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
                    </table>
                    <?php endif; ?>  
                        
                  </div>
                  
                  <div class="box-footer clearfix">
                    <div class="pull-left">
                    <ul class="pagination no-margin">
                      <?php echo e($pubs->links()); ?>

                   </ul>
                   </div>
                   <div class="pull-right">
                      
                   </div>
                  </div>
                </div>
                <!-- /.box -->
              </div>
            </div>
          <!-- ./row -->
        </section>
        <!-- /.content -->
      </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>