<div class="col-md-4">
                <aside class="right-sidebar">
                    <div class="search-widget">
                        <div class="input-group">
                        <form action="<?php echo e(route('index')); ?>" action="post">
                          <input type="text" class="form-control input-lg" name="term" placeholder="Search for...">
                          <span class="input-group-btn">
                            <button class="btn btn-lg btn-default" type="submit">
                                <i class="fa fa-search"></i>
                            </button>
                          </span>
                          </form>
                        </div><!-- /input-group -->
                        
                    </div>

                    <div class="widget">
                          <div class="widget-heading">
                           <h4>Categories</h4>
                         </div>
                        <div class="widget-body">
                            <ul class="categories">

                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                 <a href="<?php echo e(route('category',$category->slug)); ?>"><i class="fa fa-angle-right"></i><?php echo e($category->title); ?></a>
                                 <span class="badge pull-right"><?php echo e($category->posts->count()); ?></span>
                               </li>
                                                    
                                                    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                        </ul>
                        </div>
                     </div>

                   
                    <div class="widget">
                        <div class="widget-heading">
                            <h4>Popular Posts</h4>
                        </div>
                        <div class="widget-body">
                            <ul class="popular-posts">

                              <?php $__currentLoopData = $populars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $polular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="post-image">
                                        <a href="#">
                                            <img src="<?php echo e($polular->image); ?>" />
                                        </a>
                                    </div>
                                    <div class="post-body">
                                        <h6><a href="<?php echo e(route('showpost',$polular->slug)); ?>"><?php echo e($polular->title); ?></a></h6>
                                        <div class="post-meta">
                                            <span><?php echo e($polular->published_at->diffForHumans()); ?></span>
                                        </div>
                                    </div>
                                </li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </ul>
                        </div>
                    </div>

                    <div class="widget">
                        <div class="widget-heading">
                            <h4>Tags</h4>
                        </div>
                        <div class="widget-body">
                            <ul class="tags">
                                <li><a href="#">PHP</a></li>
                                <li><a href="#">Codeigniter</a></li>
                                <li><a href="#">Yii</a></li>
                                <li><a href="#">Laravel</a></li>
                                <li><a href="#">Ruby on Rails</a></li>
                                <li><a href="#">jQuery</a></li>
                                <li><a href="#">Vue Js</a></li>
                                <li><a href="#">React Js</a></li>
                            </ul>
                        </div>
                    </div>
                </aside>
            </div>