<?php $__env->startSection('title','Add New Post'); ?> 
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            <?php if($users->exists): ?>
             
             update User
            <?php else: ?>

            Add New User

            <?php endif; ?>
            
          </h1>
          <ol class="breadcrumb">
            <li>
            <a href="<?php echo e(route('home')); ?>">
            <i class="fa fa-dashboard"></i> Dashboard
            </a>
            </li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
              <div class="col-xs-12">
                <div class="box">
                  <!-- /.box-header -->
                           
                  
                  <div class="box-body ">

                  <?php echo Form::model($users, [

                   'method'=>'Post',

                   'route' => 'users.store',

                   'files'=>TRUE,

                   ]); ?>


                    <div class="form-group <?php echo e($errors->has('name') ? 'has-error' :''); ?>">
                      
                      <?php echo Form::label('name'); ?>


                     <?php echo Form::text('name', null,['class'=>'form-control']); ?>


                      <?php if($errors->has('name')): ?>

                      <span class="help-block"><?php echo e($errors->first('name')); ?></span>

                      <?php endif; ?>
                    </div>

                    
                   <div class="form-group <?php echo e($errors->has('email') ? 'has-error' :''); ?>">
                      
                      <?php echo Form::label('email'); ?>


                     <?php echo Form::text('email', null,['class'=>'form-control']); ?>


                      <?php if($errors->has('email')): ?>

                      <span class="help-block"><?php echo e($errors->first('email')); ?></span>

                      <?php endif; ?>
                    </div>

                    <div class="form-group <?php echo e($errors->has('password') ? 'has-error' :''); ?>">
                      
                      <?php echo Form::label('password'); ?>

                     <br>
                     <?php echo Form::password('password', null,['class'=>'form-control']); ?>

                     
                      <?php if($errors->has('password')): ?>

                      <span class="help-block"><?php echo e($errors->first('password')); ?></span>

                      <?php endif; ?>
                    </div>

                    <div class="form-group <?php echo e($errors->has('password_confirmation') ? 'has-error' :''); ?>">
                      
                      <?php echo Form::label('password_confirmation'); ?>

                     <br>
                     <?php echo Form::password('password_confirmation', null,['class'=>'form-control']); ?>

                    
                      <?php if($errors->has('password_confirmation')): ?>

                      <span class="help-block"><?php echo e($errors->first('password_confirmation')); ?></span>

                      <?php endif; ?>
                    </div>
                                     
                          <div class="form-group">
                      
                      <?php echo Form::label('id','Role'); ?>


                       <?php echo Form::select('id',App\Listrole ::pluck('title','id'), null,['class'=>'form-control']); ?>

                            </div>
                    

                    <hr>

                    <?php echo Form::submit('Create New User',['class'=>'btn btn-primary']);; ?>



                    <?php echo Form::close(); ?>

                        
                  </div>
                  
                 
                </div>
                <!-- /.box -->
              </div>
            </div>
          <!-- ./row -->
        </section>
        <!-- /.content -->
      </div>


     
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.backend.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>