
                                <!-- Post Items Title Start -->
                                <div class="post--items-title">
                                    <h2 class="h4"><?php echo e(count($comments)); ?> Commentaires</h2>

                                    <i class="icon fa fa-comments-o"></i>
                                </div>
                                <!-- Post Items Title End -->

                                <ul class="comment--items nav">

                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <!-- Comment Item Start -->
                                        <div class="comment--item clearfix">
                                            

                                            <div class="comment--info">
                                                <div class="comment--header clearfix">
                                                    <p class="name"><?php echo e($comment->name); ?></p>
                                                    <p class="date"><?php echo e($comment->created_at); ?></p>

                                                    <a href="#" class="reply"><i class="fa fa-mail-reply"></i></a>
                                                </div>

                                                <div class="comment--content">
                                                    <p><?php echo e($comment->body); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- Comment Item End -->
                                    </li>
                           
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </ul>
                            