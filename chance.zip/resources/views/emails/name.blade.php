<div>
   Merci d'etre un membre dans notre Association: {{ $name }}
</div>