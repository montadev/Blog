<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Listrole extends Model
{
    protected $fillable = ['listroles'];
}
